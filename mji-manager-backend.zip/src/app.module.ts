import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { UserModule } from './user/user.module';
import { DatabaseModule } from './database/database.module';
import { AppConfigModule } from './config/config.module';
import { SystemModule } from './system/system.module';
import { AppDataModule } from './appData/appData.module';
import { FunctionsModule } from './appData/functions.module';

@Module({
  imports: [
    AuthModule,
    UserModule,
    DatabaseModule,
    AppConfigModule,
    SystemModule,
    AppDataModule,
    FunctionsModule,
  ],
})
export class AppModule {}
