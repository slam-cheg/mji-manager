export function timeStamp(): string {
  return new Date().toISOString();
}