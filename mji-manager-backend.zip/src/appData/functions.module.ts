import { FunctionsService } from './functions.service';
import { Module } from '@nestjs/common';

@Module({
  imports: [],
  providers: [FunctionsService],
  exports: [FunctionsService],  // Ensure that FunctionsService is exported
})
export class FunctionsModule {}
