// functions.service.ts
import { Injectable } from '@nestjs/common';
import { AppDataService } from 'src/appData/appData.service';
import { ConfigService } from '../config/config.service';

@Injectable()
export class FunctionsService {
  constructor(
    private readonly appDataService: AppDataService,
    private readonly configService: ConfigService
  ) {}

  // Метод для получения списка функций из БД
  async getFunctionsFromDb() {
    const appData = await this.appDataService.getAppData(); // Получаем данные из BД через AppDataService
    return appData.functions;  // Возвращаем флаг функций
  }

  // Метод для обновления функций из конфигурации
  updateFunctionsFromConfig(functions: Record<string, any>) {
    return this.configService.updateActiveFunctions(functions);  // Логика обновления через ConfigService
  }
}
