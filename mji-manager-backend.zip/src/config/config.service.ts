import { Injectable } from '@nestjs/common';
import { writeFileSync, readFileSync } from 'fs';
import * as path from 'path';
import { FunctionsService } from '../appData/functions.service';  // Импортируем новый сервис

@Injectable()
export class ConfigService {
  private readonly flagsFilePath: string;

  constructor(private readonly functionsService: FunctionsService) {
    this.flagsFilePath = path.join(__dirname, '../../appConfig/appFlags.json');
  }

  updateActiveFunctions(functions: Record<string, any>): boolean {
    try {
      writeFileSync(this.flagsFilePath, JSON.stringify(functions, null, 2));  // Обновление конфигурации
      return true;
    } catch (error) {
      console.error('Ошибка при записи в activeFunctions.json:', error);
      return false;
    }
  }

  getFunctionsList(): Record<string, any> {
    try {
      const data = readFileSync(this.flagsFilePath, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      console.error('Ошибка чтения appFlags.json:', error);
      return {};
    }
  }
}
